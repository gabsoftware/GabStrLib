#include <string>
using namespace std;

#ifndef _DLL_H_
#define _DLL_H_

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */


extern "C" {
       DLLIMPORT int Test(int a);
       DLLIMPORT const char* Replace(const char* source, const char* search, const char* replace);
}


#endif /* _DLL_H_ */
//-DBUILDING_DLL