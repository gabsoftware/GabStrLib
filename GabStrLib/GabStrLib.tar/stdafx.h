// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "asmlib\asmlib.h"
#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>



// TODO: reference additional headers your program requires here


#include <string>

struct sReplace
{
	char* search;
	int search_start;
	int search_length;
	char* replace;
	int replace_length;
};

using namespace std;

#ifndef _DLL_H_
#define _DLL_H_

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */

char* stristr(register const char* Source, register const char* What);
char* fast_strstr(const char* phaystack, const char* pneedle);

extern "C" {
	DLLIMPORT bool Load();
	DLLIMPORT int Unload();
	DLLIMPORT char* Replace(const char* source, const char* search, const char* replace, size_t* size);
	DLLIMPORT char* TReplace(const char* source, const char** t_search, const char** t_replace, int nbsearch, size_t* size);
	DLLIMPORT char* Fast_Replace(const char* source, const int search_start, const int search_length, const char* replace, const int replace_length, size_t* size);
	DLLIMPORT char* Fast_TReplace(const char* source, sReplace t_search[], int nbsearch, size_t* size);
}

#endif /* _DLL_H_ */